# angular-php-example
Angular 7 Application with PHP Back-End

For details on how to implement and run this project see:

[Angular 7|6 with PHP and MySQL RESTful CRUD Example & Tutorial](https://www.techiediaries.com/php-angular)


[Angular 7|6 with PHP: Consuming a RESTful CRUD API with HttpClient and Forms](https://www.techiediaries.com/php-angular-crud-api-httpclient-forms)
