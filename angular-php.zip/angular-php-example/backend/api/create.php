<?php
require 'database.php';

// Get the posted data.
$postdata = file_get_contents("php://input");

if(isset($postdata) && !empty($postdata))
{
  // Extract the data.
  $request = json_decode($postdata);
	

  // Validate.
  if( (float)$request->amount < 0)
  {
    return http_response_code(400);
  }
	
  // Sanitize. 
  //$number = mysqli_real_escape_string($con, trim($request->number));
  $amount = mysqli_real_escape_string($con, (int)$request->amount);

  //read date
  $sql_getdate = "SELECT weekdate FROM policies ORDER BY id DESC LIMIT 1;";
  $result = mysqli_query($con,$sql_getdate); //connect
  $row = mysqli_fetch_assoc($result);
  $fetched_date = $row['weekdate'];


  //write date
  if($fetched_date == null){
    $weekdate = mysqli_real_escape_string($con, "2018-12-30");
  }
  else{
    $date = strtotime("+7 day", strtotime($fetched_date));
    $weekdate = mysqli_real_escape_string($con,date("Y-m-d", $date));
  }

  $number = mysqli_real_escape_string($con, date("W", strtotime($weekdate))); //weeknumber 
  // Store.

  //ID
  $sql_getID = "SELECT id FROM policies ORDER BY id DESC LIMIT 1;";
  $resultID = mysqli_query($con,$sql_getID); //connect
  $row = mysqli_fetch_assoc($resultID);
  $fetched_id = $row['id'];

  if($fetched_id == null){
    $id = mysqli_real_escape_string($con, 1);
  }
  else{
    $fid = $fetched_id+0;
    $id = $fid + 1;
  }
  //
  $sql = "INSERT INTO `policies`(`id`,`number`,`amount`,`weekdate`) VALUES ('{$id}','{$number}','{$amount}','{$weekdate}');";
  $sql .= " INSERT INTO `WSC`(`id`,`wsc_id`) VALUES ('{$id}',$amount)";
  if(mysqli_multi_query($con,$sql))
  {
    http_response_code(201);
    $policy = [
      'weekdate' => $weekdate,
      'number' => $number,
      'amount' => $amount,
      'id'    => $id,
      'fetched_id' => $fetched_id,
      'fid' => $fid,   
    ];
    echo json_encode($policy);
  }
  else
  {
    http_response_code(422);
  }
}